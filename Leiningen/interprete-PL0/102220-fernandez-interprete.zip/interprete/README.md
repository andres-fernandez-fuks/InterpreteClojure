# interprete_pl0

## Uso

Ejecutar lain.run en la carpeta interprete para correr el programa.

Ejecutar lain.test en la carpeta interprete para correr las pruebas del programa.